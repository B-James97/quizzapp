export interface Question {
    question: string;
    answer: boolean;
    moreInfo: string;
}
