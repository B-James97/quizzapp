import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { KestyonPage } from './kestyon';

@NgModule({
  declarations: [
    KestyonPage,
  ],
  imports: [
    IonicPageModule.forChild(KestyonPage),
  ],
})
export class KestyonPageModule {}
